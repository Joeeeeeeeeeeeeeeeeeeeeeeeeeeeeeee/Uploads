import {Component, OnInit} from '@angular/core';
import {ContactService} from "../../services/contacts.service";
import {Contact} from "./contact";
import {updatePlaceholderMap} from "@angular/compiler/src/render3/view/i18n/util";

@Component({
  selector: 'app-contacts',
  templateUrl: './contacts.component.html',
  styleUrls: ['./contacts.component.css'],
  providers: [ContactService]
})
export class ContactsComponent implements OnInit {
  public contacts = [];
  public model = {newFirstName: '', newLastName: '', newEmail: ''};
  public newFirstName;
  public newLastName;
  public newEmail;
  public editing;

  constructor(private contactService: ContactService) {
  }

  ngOnInit(): void {
    this.readAll();
  }

  private readAll() {
    return this.contactService.loadAll().subscribe((list) => {
      this.contacts = list;
      // console.log("Contacts:",this.contacts)
      // // this.contacts.push({id: 3, email: 'test@test.com', firstName: 'test', lastName: 'test'})
    });
  }

  editUser(contact: Contact) {
    this.editing = true;
  }

  submitEdit(contact: Contact) {
    if (this.model.newFirstName)
      contact.firstName = this.model.newFirstName;
    if (this.model.newLastName)
      contact.lastName = this.model.newLastName;
    if (this.model.newEmail)
      contact.email = this.model.newEmail;

    this.contactService.putContact(contact).subscribe(contact => {
        console.log('object saved', contact);
        this.editing= false;
    });
  }
}
