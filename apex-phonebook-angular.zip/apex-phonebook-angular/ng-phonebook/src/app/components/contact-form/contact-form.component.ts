import {Component, OnInit} from '@angular/core';
import {ContactService} from "../../services/contacts.service";
import {NgForm} from "@angular/forms";
import {Contact} from "../contact-list/contact";

@Component({
    selector: 'app-contact-form',
    templateUrl: './contact-form.component.html',
    styleUrls: ['./contact-form.component.css']
})
export class ContactFormComponent implements OnInit {
    model = <Contact> {};
    submitted = false;
    btnName = 'Submit Now';

    constructor(private contactService: ContactService) {
    }

    ngOnInit(): void {
    }

    createNew(f,l,e) {
        return  {firstName: f, lastName: l, email: e} as Contact;
    }

    onSubmit(contactForm: NgForm) {
        this.submitted = true;

        this.contactService.postContact(this.model)
            .subscribe(contact => {
                console.log('object saved', contact, this.model);
                this.model = this.createNew(
                    contact.firstName,
                    contact.lastName,
                    contact.email
                );
                this.submitted = false;
                contactForm.resetForm();
            });

        console.log('submitted');
    }

    get diagnostic() {
        return JSON.stringify(this.model);
    }

}
