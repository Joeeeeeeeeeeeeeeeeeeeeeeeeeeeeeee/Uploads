export const data = [
    {
        id: 1,
        email: 'a@a.com',
        firstName: 'Jon',
        lastName: 'Smith'
    },
    {
        id: 2,
        email: 'm@m.com',
        firstName: 'Marry',
        lastName: 'White'
    }
]
